# Known bugs
Bugs:
- When Windows Desktop size is not 100%, application window "touchable" area isn't the right size. Drag the window to fix this.
- Need to run as Administrator on Mac OS (due to janky `chmodsync` library)
